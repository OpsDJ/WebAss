const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const fs = require("fs");
const { log } = require("console");
const app = express();
const PORT = 9000;

app.use(bodyParser.json());
app.use(cors());

const usersFile = "./public/data/users.json";
const messagesFile = "./public/data/messages.json";
const todosFile = "./public/data/todos.json";
const articlesFile = "./public/data/articles.json";

// 确保初始文件存在
if (!fs.existsSync(usersFile)) {
  fs.writeFileSync(usersFile, JSON.stringify([]));
}
if (!fs.existsSync(messagesFile)) {
  fs.writeFileSync(messagesFile, JSON.stringify([]));
}
if (!fs.existsSync(todosFile)) {
  fs.writeFileSync(todosFile, JSON.stringify([]));
}
if (!fs.existsSync(articlesFile)) {
  fs.writeFileSync(articlesFile, JSON.stringify([]));
}

// 用户注册
app.post("/register", (req, res) => {
  const { username, password, email, gender, birthdate, bio } = req.body;
  const users = JSON.parse(fs.readFileSync(usersFile));
  if (!username) {
    return res.status(400).send("需要用户名！");
  }
  if (!password) {
    return res.status(400).send("需要密码！");
  }
  if (!email) {
    return res.status(400).send("需要邮箱！");
  }
  if (
    users.find((user) => user.username === username || user.email === email)
  ) {
    return res.status(409).send("用户已存在");
  }
  const newUser = {
    id: users.length + 1,
    username,
    password,
    email,
    gender,
    birthdate,
    bio,
  };
  users.push(newUser);
  fs.writeFileSync(usersFile, JSON.stringify(users));
  res.send("注册成功");
});

// 用户登录
app.post("/login", (req, res) => {
  const { username, password } = req.body;
  const users = JSON.parse(fs.readFileSync(usersFile));
  const user = users.find(
    (user) => user.username === username && user.password === password
  );
  if (user) {
    res.send({
      message: "登录成功！",
      user: {
        userID: user.id,
        username: user.username,
        email: user.email,
        gender: user.gender,
        birthdate: user.birthdate,
        bio: user.bio,
      },
    });
  } else {
    res.status(401).send("无效登录！");
  }
});

// 用户登出
app.post("/logout", (req, res) => {
  res.send("用户已登出");
});

// 发布消息
app.post("/post", (req, res) => {
  const { username, message } = req.body;
  const messages = JSON.parse(fs.readFileSync(messagesFile));
  messages.push({
    id: messages.length + 1,
    username,
    message,
    timestamp: new Date().toISOString(),
  });
  fs.writeFileSync(messagesFile, JSON.stringify(messages));
  res.send("信息已发送");
});

// 获取所有消息
app.get("/messages", (req, res) => {
  const messages = JSON.parse(fs.readFileSync(messagesFile));
  res.json(messages);
});

// 删除消息
app.delete("/messages/:id", (req, res) => {
  const { id } = req.params;
  let messages = JSON.parse(fs.readFileSync(messagesFile));
  const originalLength = messages.length;
  messages = messages.filter((message) => message.id.toString() !== id);

  if (messages.length === originalLength) {
    res.status(404).send("没有这条消息！");
  } else {
    fs.writeFileSync(messagesFile, JSON.stringify(messages));
    res.send("消息已删除！");
  }
});

// 通过ID获取消息
app.get("/messages/:id?", (req, res) => {
  const messages = JSON.parse(fs.readFileSync(messagesFile));
  const id = req.params.id;

  if (!id) {
    res.json(messages);
  } else {
    const message = messages.find((msg) => msg.id === parseInt(id));
    if (message) {
      res.json(message);
    } else {
      res.status(404).send("Message not found");
    }
  }
});

// 发布代办事项
app.post("/todos", (req, res) => {
  const { userID, content } = req.body;
  const todos = JSON.parse(fs.readFileSync(todosFile));
  const newTodo = {
    id: todos.length + 1,
    userID,
    content,
    timestamp: new Date().toISOString(),
  };
  todos.push(newTodo);
  fs.writeFileSync(todosFile, JSON.stringify(todos));
  res.send("代办事项已添加");
});

// 展示用户的代办事项
app.get("/todos/list/:userID", (req, res) => {
  const { userID } = req.params;
  const todos = JSON.parse(fs.readFileSync(todosFile));
  const userTodos = todos.filter((todo) => todo.userID.toString() === userID);
  res.json(userTodos);
});

// 根据id搜索todo
app.post("/todos/search", (req, res) => {
  const { userID, id } = req.body;
  const todos = JSON.parse(fs.readFileSync(todosFile));
  const userTodos = todos.filter((todo) => todo.userID.toString() === userID);

  if (!id) {
    return res.json(userTodos);
  }

  const filteredTodos = userTodos.filter(
    (todo) => todo.id.toString() === id.toString()
  );
  if (filteredTodos.length === 0) {
    return res.status(404).json({ error: "Todo not found" });
  }else{
    res.json(filteredTodos);

  }
});

// 删除代办事项
app.delete("/todos/:id", (req, res) => {
  const { id } = req.params;
  let todos = JSON.parse(fs.readFileSync(todosFile));
  todos = todos.filter((todo) => todo.id.toString() !== id);
  fs.writeFileSync(todosFile, JSON.stringify(todos));
  res.send("代办事项已删除");
});

// 发布文章
app.post("/articles", (req, res) => {
  const { userID, title, body, username } = req.body;
  const articles = JSON.parse(fs.readFileSync(articlesFile));
  const newArticle = { id: articles.length + 1, userID, username, title, body, timestamp: new Date().toISOString() };
  articles.push(newArticle);
  fs.writeFileSync(articlesFile, JSON.stringify(articles));
  res.send("文章已添加！");
});

// 展示文章
app.get("/articles", (req, res) => {
  const articles = JSON.parse(fs.readFileSync(articlesFile));
  res.json(articles);
});

// 根据文章标题搜索文章
app.get("/articles/search", (req, res) => {
  const { title } = req.query;
  const articles = JSON.parse(fs.readFileSync(articlesFile));
  if (!title) {
    return res.json(articles);
  }

  const filteredArticles = articles.filter((article) =>
    article.title.includes(title)
  );
  if (filteredArticles.length === 0) {
    return res.status(404).json({ message: "No articles found" });
  }else {
    res.json(filteredArticles);

  }
});

// 删除文章
app.delete("/articles/:id", (req, res) => {
  const { id } = req.params;
  const { userID } = req.body;
  let articles = JSON.parse(fs.readFileSync(articlesFile));
  // userID = userID.toString();
  const article = articles.find(
    (article) => article.userID === userID && article.id.toString() === id
  );
  if (article) {
    articles = articles.filter((article) => article.id.toString() !== id);
    fs.writeFileSync(articlesFile, JSON.stringify(articles));
    res.send("文章已删除！");
  } else {
    res.status(401).send("你没有权限删除这篇文章！");
  }
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
